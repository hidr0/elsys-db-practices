use a;

insert into Blog values(null, 'purviblog', 0);
insert into Blog values(null, 'vtoriblog', 0);
insert into Blog values(null, 'tretiblog', 0);

insert into BlogPost values(null, 'purvipost', 1);
insert into BlogPost values(null, 'vtroipost', 2);
insert into BlogPost values(null, 'tretipost', 3);

insert into User values(null, 'pesho');
insert into User values(null, 'gesho');
insert into User values(null, 'mesho');

insert into Likes values(null, 1, 1);
insert into Likes values(null, 3, 2);
insert into Likes values(null, 3, 3);
insert into Likes values(null, 1, 2);
insert into Likes values(null, 1, 1);